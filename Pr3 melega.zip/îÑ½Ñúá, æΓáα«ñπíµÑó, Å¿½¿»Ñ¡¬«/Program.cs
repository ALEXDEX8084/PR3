﻿namespace Pr3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char[,] sypher = { { 'A', 'B', 'C', 'D', 'E' }, { 'F', 'G', 'H', 'I', 'K' }, { 'L', 'M', 'N', 'O', 'P' }, { 'Q', 'R', 'S', 'T', 'U' }, { 'V', 'W', 'X', 'Y', 'Z' } };
            Console.WriteLine("Введите сообщение латинскими буквами для шифровки: ");
            string message = Console.ReadLine();
            string code = "";
            //string path = "text.txt";
            //StreamWriter writer = new StreamWriter(path, false);
            for (int i = 0; i < message.Length; i++)
            {
                for (int j = 0; j < sypher.GetLength(0); j++)
                    for (int k = 0; k < sypher.GetLength(1); k++)
                        if (Char.ToLower(sypher[j, k]) == message[i] || Char.ToUpper(sypher[j, k]) == message[i])
                        {
                            code += (Convert.ToString(j) + Convert.ToString(k));
                            break;
                        }
            }
            Console.WriteLine(code);
            File.WriteAllText("WriteText.txt", message + ' ' + code);
            Console.WriteLine("Введите шифр: ");
            code = Console.ReadLine();
            message = "";
            for (int a = 0; a < code.Length; a += 2)
            {
                message += sypher[Convert.ToInt32(code[a].ToString()), Convert.ToInt32(code[a + 1].ToString())];
            }
            Console.WriteLine(message);
            string[] lines = System.IO.File.ReadAllLines(@"WriteText.txt");
            foreach (string line in lines)
            {
                Console.WriteLine("\t" + line);
            }
            Console.ReadKey();
        }
    }
}

